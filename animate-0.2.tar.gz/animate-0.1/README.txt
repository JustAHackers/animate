python animations
